# Playwright Automation for www.generasimaju.co.id

Automated tests run daily at 05.00 WIB via GitHub Actions.